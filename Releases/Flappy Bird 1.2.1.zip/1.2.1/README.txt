Thank you for download Flappy Bird version 1.2.1!

Original game by Dong Nguyen.
Windows version by Josh Dittmer.

HOW TO PLAY-
Left click with your mouse to make the Flappy Bird jump. Navigate between the pipes without hitting them!
When you die, simply click the mouse again to restart. (score board will be added eventually!)

HOW TO INSTALL-
For quick and easy access to Flappy Bird, drag the "Play Flappy Bird" file onto your desktop.
Keep the original folder with the original files in a place where it won't get deleted!
Deleted any of the files in the original folder WILL break Flappy Bird, and it will no longer run on your computer.
If you have accidentally deleted any of the files, please redownload Flappy Bird.